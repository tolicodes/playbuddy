import { b as API_ENV_KEY, A as AUTO_FETLIFE_KEY, a as AUTO_FETLIFE_NEARBY_KEY } from './config-Dvlt12WH.js';

true              &&(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
}());

const SOURCE_LABELS = {
  fetlife: "FetLife Events (deprecated)",
  fetlifeNearby: "FetLife Nearby (HTML)",
  fetlifeNearbyApi: "FetLife Nearby (API)",
  fetlifeFestivals: "FetLife Festivals",
  fetlifeFriendsStage1: "FetLife Friends Stage 1",
  fetlifeFriendsStage2: "FetLife Friends Stage 2",
  fetlifeFriendsApiStage1: "FetLife Friends API Stage 1",
  fetlifeFriendsApiStage2: "FetLife Friends API Stage 2",
  fetlifeSingle: "FetLife Single Handle",
  instagram: "Instagram",
  tickettailor: "TicketTailor",
  pluraPromoStats: "Plura Promo Stats"
};
const LS_KEY = "PLAYBUDDY_API_KEY";
const RUN_LOG_KEY = "PB_SCRAPE_LOGS";
const TABLE_LOGS_KEY = "PB_TABLE_LOGS";
const PROGRESS_KEY = "PB_PROGRESS_LOGS";
const LIVE_LOG_KEY = "PB_LIVE_LOG";
const TEST_MODE_KEY = "PB_TEST_MODE";
const SKIP_OVERWRITE_KEY = "PB_SKIP_OVERWRITE";
const TABLE_LOG_KEY = "PB_TABLE_HTML";
const MAX_EVENTS_KEY = "PB_MAX_EVENTS";
let cachedRunLogs = [];
let cachedProgressRuns = [];
let cachedRunTables = [];
let selectedRunId = null;
let latestTableHtml = "";
function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (ch) => {
    const map = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    };
    return map[ch] || ch;
  });
}
function formatDuration(ms) {
  if (typeof ms !== "number" || !Number.isFinite(ms)) return "n/a";
  return `${Math.round(ms / 1e3)}s`;
}
function formatDateTime(ts) {
  if (typeof ts !== "number" || !Number.isFinite(ts)) return "n/a";
  return new Date(ts).toLocaleString();
}
function sourceLabel(source) {
  return SOURCE_LABELS[source] || source;
}
function labelFromRunId(runId) {
  if (runId.startsWith("branch-stats")) return "Branch stats";
  const base = runId.split("-")[0] || runId;
  return sourceLabel(base);
}
function getLatestRunId() {
  return cachedRunLogs[0]?.id || cachedProgressRuns[0]?.runId || null;
}
function getRunTableEntry(runId) {
  if (!runId) return null;
  return cachedRunTables.find((entry) => entry.runId === runId) || null;
}
function tableLabelForRun(runId) {
  if (!runId) return "Latest run";
  const run = cachedRunLogs.find((r) => r.id === runId);
  if (run) return sourceLabel(run.source);
  const progress = cachedProgressRuns.find((p) => p.runId === runId);
  if (progress) return labelFromRunId(progress.runId);
  return "Run table";
}
function normalizeTableHtml(raw) {
  let html = raw || "";
  if (!html) return "";
  if (html.includes("<table") && !html.includes("status-table")) {
    html = html.replace("<table", '<table class="status-table"');
  }
  html = html.replace(/style="color:#fff;?"/g, "");
  if (!html.includes("status-table-link")) {
    html = html.replace(/<a(?![^>]*class=)/g, '<a class="status-table-link"');
  }
  return html;
}
function init() {
  const apiKeyInput = document.getElementById("apiKey");
  const saveBtn = document.getElementById("saveApiKey");
  const testModeCheckbox = document.getElementById("testMode");
  const skipOverwriteCheckbox = document.getElementById("skipOverwrite");
  const maxEventsInput = document.getElementById("maxEvents");
  const apiStatus = document.getElementById("apiStatus");
  const apiEnvSelect = document.getElementById("apiEnv");
  const autoFetlifeCheckbox = document.getElementById("autoFetlife");
  const runLogsDiv = document.getElementById("runLogs");
  const logDiv = document.getElementById("log");
  const tableDiv = document.getElementById("tableOutput");
  const stage2Input = document.getElementById("stage2File");
  const stage2Btn = document.getElementById("startFetlifeFriendsStage2");
  const stage2ApiBtn = document.getElementById("startFetlifeFriendsApiStage2");
  const singleHandleInput = document.getElementById("singleFetlifeHandle");
  const singleHandleBtn = document.getElementById("startSingleFetlifeHandle");
  const branchStatsBtn = document.getElementById("startBranchStats");
  const runDetailTitle = document.getElementById("runDetailTitle");
  const runDetailMeta = document.getElementById("runDetailMeta");
  const runDetailLog = document.getElementById("runDetailLog");
  const runTableLabel = document.getElementById("runTableLabel");
  const runDetailSkipReasons = document.getElementById("runDetailSkipReasons");
  if (!apiKeyInput || !saveBtn || !apiStatus) {
    console.warn("Options page failed to find API key inputs.");
    return;
  }
  function setApiStatus(text, state) {
    if (!apiStatus) return;
    apiStatus.textContent = text;
    apiStatus.dataset.state = state;
  }
  if (apiEnvSelect) {
    chrome.storage.local.get(API_ENV_KEY, (res) => {
      const val = res[API_ENV_KEY] || "local";
      apiEnvSelect.value = val;
    });
    apiEnvSelect.addEventListener("change", () => {
      chrome.storage.local.set({ [API_ENV_KEY]: apiEnvSelect.value || "local" });
    });
  }
  if (autoFetlifeCheckbox) {
    chrome.storage.local.get([AUTO_FETLIFE_KEY, AUTO_FETLIFE_NEARBY_KEY], (res) => {
      autoFetlifeCheckbox.checked = !!res[AUTO_FETLIFE_KEY] || !!res[AUTO_FETLIFE_NEARBY_KEY];
    });
    autoFetlifeCheckbox.addEventListener("change", () => {
      const enabled = !!autoFetlifeCheckbox.checked;
      chrome.storage.local.set({
        [AUTO_FETLIFE_KEY]: enabled,
        [AUTO_FETLIFE_NEARBY_KEY]: enabled
      });
    });
  }
  function loadApiKey() {
    if (!apiKeyInput || !apiStatus) return;
    chrome.storage.local.get(LS_KEY, (result) => {
      const existing = result[LS_KEY] ?? "";
      apiKeyInput.value = existing;
      if (existing) {
        setApiStatus("Saved", "saved");
      } else {
        setApiStatus("Not saved", "empty");
      }
    });
  }
  function saveApiKey() {
    if (!apiKeyInput || !apiStatus) return;
    const val = apiKeyInput.value.trim();
    if (!val) {
      setApiStatus("Missing key", "empty");
      return;
    }
    chrome.storage.local.set({ [LS_KEY]: val }, () => {
      setApiStatus("Saved", "saved");
    });
  }
  saveBtn.addEventListener("click", saveApiKey);
  loadApiKey();
  if (testModeCheckbox) {
    chrome.storage.local.get(TEST_MODE_KEY, (res) => {
      testModeCheckbox.checked = !!res[TEST_MODE_KEY];
    });
    testModeCheckbox.addEventListener("change", () => {
      chrome.storage.local.set({ [TEST_MODE_KEY]: !!testModeCheckbox.checked });
    });
  }
  if (skipOverwriteCheckbox) {
    chrome.storage.local.get(SKIP_OVERWRITE_KEY, (res) => {
      skipOverwriteCheckbox.checked = !!res[SKIP_OVERWRITE_KEY];
    });
    skipOverwriteCheckbox.addEventListener("change", () => {
      chrome.storage.local.set({ [SKIP_OVERWRITE_KEY]: !!skipOverwriteCheckbox.checked });
    });
  }
  if (maxEventsInput) {
    chrome.storage.local.get(MAX_EVENTS_KEY, (res) => {
      const n = Number(res[MAX_EVENTS_KEY]);
      if (Number.isFinite(n) && n > 0) maxEventsInput.value = String(n);
    });
    maxEventsInput.addEventListener("change", () => {
      const n = Number(maxEventsInput.value);
      if (Number.isFinite(n) && n > 0) {
        chrome.storage.local.set({ [MAX_EVENTS_KEY]: n });
      } else {
        chrome.storage.local.remove(MAX_EVENTS_KEY);
      }
    });
  }
  function bindScrapeButton(buttonId, sourceName) {
    const button = document.getElementById(buttonId);
    if (!button) return;
    button.addEventListener("click", () => {
      chrome.runtime.sendMessage(
        { action: "scrapeSingleSource", source: sourceName },
        (response) => {
          console.log(`Response from background (${sourceName}):`, response);
        }
      );
    });
  }
  const deprecatedFetlifeBtn = document.getElementById("startFetlife");
  if (deprecatedFetlifeBtn) {
    deprecatedFetlifeBtn.disabled = true;
    deprecatedFetlifeBtn.title = "Deprecated: use FetLife Nearby or Festivals.";
  }
  bindScrapeButton("startFetlifeNearby", "fetlifeNearby");
  bindScrapeButton("startFetlifeNearbyApi", "fetlifeNearbyApi");
  bindScrapeButton("startFetlifeFestivals", "fetlifeFestivals");
  bindScrapeButton("startFetlifeFriendsStage1", "fetlifeFriendsStage1");
  bindScrapeButton("startFetlifeFriendsApiStage1", "fetlifeFriendsApiStage1");
  bindScrapeButton("startInstagram", "instagram");
  bindScrapeButton("startTicketTailor", "tickettailor");
  bindScrapeButton("startPluraPromoStats", "pluraPromoStats");
  branchStatsBtn?.addEventListener("click", () => {
    chrome.runtime.sendMessage(
      { action: "branchStatsScrape" },
      (response) => {
        console.log("Branch stats scrape response:", response);
      }
    );
  });
  async function readStage2File(file) {
    const text = await file.text();
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      return [];
    }
    if (!Array.isArray(parsed)) return [];
    const normalize = (value) => value.trim().replace(/^@+/, "").replace(/^https?:\/\/(www\.)?fetlife\.com\//i, "");
    const handles = parsed.map((row) => {
      const raw = row?.username || row?.nickname || row?.handle || row?.root_handle || row?.profile_url || row?.url || "";
      return typeof raw === "string" ? normalize(raw) : "";
    }).filter((h) => h);
    return Array.from(new Set(handles));
  }
  const runStage2 = (source) => async () => {
    if (!stage2Input || !stage2Input.files?.length) {
      alert("Please choose a Stage 1 JSON file first.");
      return;
    }
    const handles = await readStage2File(stage2Input.files[0]);
    if (!handles.length) {
      alert("No valid handles found in file.");
      return;
    }
    chrome.runtime.sendMessage({ action: "setStage2Handles", handles }, () => {
      chrome.runtime.sendMessage({ action: "scrapeSingleSource", source }, (response) => {
        console.log("Stage 2 response:", response);
      });
    });
  };
  stage2Btn?.addEventListener("click", runStage2("fetlifeFriendsStage2"));
  stage2ApiBtn?.addEventListener("click", runStage2("fetlifeFriendsApiStage2"));
  singleHandleBtn?.addEventListener("click", () => {
    if (!singleHandleInput) return;
    const handle = singleHandleInput.value.trim();
    if (!handle) {
      alert("Please enter a FetLife handle to scrape.");
      return;
    }
    chrome.runtime.sendMessage(
      { action: "scrapeSingleSource", source: "fetlifeSingle", handles: [handle] },
      (response) => {
        console.log("Single handle response:", response);
      }
    );
  });
  function persistLiveLog(line) {
    chrome.storage.local.get(LIVE_LOG_KEY, (res) => {
      const existing = res && res[LIVE_LOG_KEY] || [];
      const last = existing[existing.length - 1];
      const next = last && last.msg === line ? existing : [...existing, { ts: Date.now(), msg: line }].slice(-500);
      chrome.storage.local.set({ [LIVE_LOG_KEY]: next });
    });
  }
  function renderLogEntry(msg, ts) {
    if (!logDiv) return;
    const wrapper = document.createElement("div");
    wrapper.className = "log-line";
    const stamp = ts ? new Date(ts).toLocaleTimeString() : (/* @__PURE__ */ new Date()).toLocaleTimeString();
    if (msg.includes("<table")) {
      wrapper.innerHTML = `<span class="log-time">[${stamp}]</span> ${normalizeTableHtml(msg)}`;
    } else {
      wrapper.textContent = `[${stamp}] ${msg}`;
    }
    logDiv.appendChild(wrapper);
    logDiv.scrollTop = logDiv.scrollHeight;
  }
  function appendLog(line) {
    renderLogEntry(line);
    persistLiveLog(line);
  }
  function renderRunLogs() {
    if (!runLogsDiv) return;
    const rows = [];
    const used = /* @__PURE__ */ new Set();
    cachedRunLogs.forEach((r) => {
      used.add(r.id);
      const start = formatDateTime(r.startedAt);
      const duration = formatDuration(r.durationMs);
      const count = Number.isFinite(r.eventCount) ? String(r.eventCount) : "n/a";
      const skipped = Number.isFinite(r.skippedCount) ? r.skippedCount : null;
      const skippedLabel = skipped && skipped > 0 ? ` | skipped: ${skipped}` : "";
      const statusClass = r.status === "success" ? "success" : "error";
      const error = r.error ? ` | error: ${escapeHtml(r.error)}` : "";
      const active = r.id === selectedRunId ? "active" : "";
      rows.push(
        `<button class="run-row ${active}" data-run-id="${escapeHtml(r.id)}">
                    <div class="run-row-top">
                        <span class="run-source">${escapeHtml(sourceLabel(r.source))}</span>
                        <span class="status ${statusClass}">${escapeHtml(r.status)}</span>
                    </div>
                    <div class="run-row-meta">${escapeHtml(start)} | ${escapeHtml(duration)} | events: ${count}${escapeHtml(skippedLabel)}${error}</div>
                </button>`
      );
    });
    cachedProgressRuns.forEach((p) => {
      if (used.has(p.runId)) return;
      const start = formatDateTime(p.startedAt);
      const label = labelFromRunId(p.runId);
      const active = p.runId === selectedRunId ? "active" : "";
      rows.push(
        `<button class="run-row ${active}" data-run-id="${escapeHtml(p.runId)}">
                    <div class="run-row-top">
                        <span class="run-source">${escapeHtml(label)}</span>
                        <span class="status neutral">log-only</span>
                    </div>
                    <div class="run-row-meta">${escapeHtml(start)} | entries: ${p.entries?.length || 0}</div>
                </button>`
      );
    });
    if (!rows.length) {
      runLogsDiv.innerHTML = '<div class="muted">No runs yet.</div>';
      return;
    }
    runLogsDiv.innerHTML = rows.join("");
  }
  function renderRunDetail() {
    if (!runDetailTitle || !runDetailMeta || !runDetailLog) return;
    if (!selectedRunId) {
      runDetailTitle.textContent = "No run selected";
      runDetailMeta.innerHTML = "";
      if (runDetailSkipReasons) runDetailSkipReasons.innerHTML = '<span class="muted">Select a run to view skip reasons.</span>';
      runDetailLog.textContent = "Select a run to view its saved log.";
      return;
    }
    const run = cachedRunLogs.find((r) => r.id === selectedRunId) || null;
    const progress = cachedProgressRuns.find((p) => p.runId === selectedRunId) || null;
    const label = run ? sourceLabel(run.source) : progress ? labelFromRunId(progress.runId) : "Run";
    runDetailTitle.textContent = label;
    const skippedCount = typeof run?.skippedCount === "number" ? run.skippedCount : null;
    const metaRows = [
      { label: "Run ID", value: run?.id || progress?.runId || "n/a" },
      { label: "Status", value: run?.status || (progress ? "log-only" : "n/a") },
      { label: "Scraped", value: run ? String(run.eventCount) : "n/a" },
      { label: "Skipped", value: skippedCount !== null ? String(skippedCount) : "n/a" },
      { label: "Started", value: formatDateTime(run?.startedAt ?? progress?.startedAt) },
      { label: "Duration", value: formatDuration(run?.durationMs) },
      { label: "Uploaded", value: typeof run?.uploaded === "boolean" ? run.uploaded ? "yes" : "no" : "n/a" }
    ];
    runDetailMeta.innerHTML = metaRows.map((row) => `<div class="meta-item"><span>${escapeHtml(row.label)}</span>${escapeHtml(row.value)}</div>`).join("");
    if (runDetailSkipReasons) {
      const byReason = run?.skippedByReason || {};
      const entries2 = Object.entries(byReason).sort((a, b) => b[1] - a[1]);
      if (!entries2.length) {
        runDetailSkipReasons.innerHTML = '<span class="muted">No skipped events recorded.</span>';
      } else {
        runDetailSkipReasons.innerHTML = entries2.map(([reason, count]) => `<span class="skip-pill">${escapeHtml(reason)}: ${count}</span>`).join("");
      }
    }
    const entries = progress?.entries || [];
    if (!entries.length) {
      runDetailLog.textContent = "No log entries saved for this run.";
      return;
    }
    runDetailLog.innerHTML = entries.map((entry) => {
      const stamp = new Date(entry.ts).toLocaleTimeString();
      return `<div class="log-line"><span class="log-time">[${escapeHtml(stamp)}]</span> ${escapeHtml(entry.msg)}</div>`;
    }).join("");
  }
  function renderRunTable() {
    if (!tableDiv) return;
    const entry = getRunTableEntry(selectedRunId);
    const latestRunId = getLatestRunId();
    let html = entry?.html || "";
    if (!html) {
      if (!selectedRunId) {
        html = latestTableHtml || "";
      } else if (latestRunId && selectedRunId === latestRunId) {
        html = latestTableHtml || "";
      }
    }
    const normalized = normalizeTableHtml(html);
    if (normalized) {
      tableDiv.innerHTML = normalized;
    } else {
      tableDiv.innerHTML = selectedRunId ? '<div class="muted">No table saved for this run.</div>' : '<div class="muted">No table available yet.</div>';
    }
    if (runTableLabel) {
      runTableLabel.textContent = selectedRunId ? tableLabelForRun(selectedRunId) : latestTableHtml ? "Latest run" : "No run selected";
    }
  }
  function selectRun(runId) {
    selectedRunId = runId;
    renderRunLogs();
    renderRunDetail();
    renderRunTable();
  }
  runLogsDiv?.addEventListener("click", (event) => {
    const target = event.target.closest(".run-row");
    if (!target?.dataset?.runId) return;
    selectRun(target.dataset.runId);
  });
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.action === "log" && typeof msg.text === "string") {
      appendLog(msg.text);
    }
    if (msg?.action === "table" && typeof msg.html === "string") {
      latestTableHtml = msg.html || "";
      renderRunTable();
    }
  });
  function loadLiveLog() {
    if (!logDiv) return;
    chrome.storage.local.get(LIVE_LOG_KEY, (res) => {
      const entries = res && res[LIVE_LOG_KEY] || [];
      logDiv.innerHTML = "";
      entries.forEach((e) => renderLogEntry(e?.msg || "", e?.ts));
    });
  }
  function loadRunLogs() {
    chrome.storage.local.get(RUN_LOG_KEY, (res) => {
      cachedRunLogs = res && res[RUN_LOG_KEY] || [];
      if (!selectedRunId && cachedRunLogs.length) {
        selectedRunId = cachedRunLogs[0].id;
      }
      renderRunLogs();
      renderRunDetail();
      renderRunTable();
    });
  }
  function loadProgressRuns() {
    chrome.storage.local.get(PROGRESS_KEY, (res) => {
      cachedProgressRuns = res && res[PROGRESS_KEY] || [];
      if (!selectedRunId && cachedProgressRuns.length) {
        selectedRunId = cachedProgressRuns[0].runId;
      }
      renderRunLogs();
      renderRunDetail();
      renderRunTable();
    });
  }
  function loadRunTables() {
    chrome.storage.local.get(TABLE_LOGS_KEY, (res) => {
      cachedRunTables = res && res[TABLE_LOGS_KEY] || [];
      renderRunTable();
    });
  }
  function loadTablePreview() {
    if (!tableDiv) return;
    chrome.storage.local.get(TABLE_LOG_KEY, (res) => {
      latestTableHtml = res[TABLE_LOG_KEY] || "";
      renderRunTable();
    });
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && RUN_LOG_KEY in changes) loadRunLogs();
    if (area === "local" && PROGRESS_KEY in changes) loadProgressRuns();
    if (area === "local" && LIVE_LOG_KEY in changes) loadLiveLog();
    if (area === "local" && TABLE_LOGS_KEY in changes) loadRunTables();
    if (area === "local" && TABLE_LOG_KEY in changes) loadTablePreview();
  });
  loadRunLogs();
  loadProgressRuns();
  loadRunTables();
  loadLiveLog();
  loadTablePreview();
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
//# sourceMappingURL=options-PWw2kgkU.js.map
