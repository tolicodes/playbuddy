const TEST_MODE_KEY = "PB_TEST_MODE";
const MAX_EVENTS_KEY = "PB_MAX_EVENTS";
const API_ENV_KEY = "PB_API_ENV";
const AUTO_FETLIFE_KEY = "PB_AUTO_FETLIFE";
const AUTO_FETLIFE_NEARBY_KEY = "PB_AUTO_FETLIFE_NEARBY";
const DEFAULT_API_BASE = "http://localhost:8080";
const PROD_API_BASE = "https://api.playbuddy.me";
async function isTestMode() {
  if (typeof chrome === "undefined" || !chrome.storage?.local) return false;
  try {
    const res = await chrome.storage.local.get(TEST_MODE_KEY);
    return !!res[TEST_MODE_KEY];
  } catch {
    return false;
  }
}
async function getApiBase() {
  if (typeof chrome === "undefined" || !chrome.storage?.local) return DEFAULT_API_BASE;
  try {
    const res = await chrome.storage.local.get(API_ENV_KEY);
    const env = res[API_ENV_KEY];
    if (env === "prod") return PROD_API_BASE;
    if (typeof env === "string" && env.startsWith("http")) return env;
  } catch {
  }
  return DEFAULT_API_BASE;
}

export { AUTO_FETLIFE_KEY as A, MAX_EVENTS_KEY as M, AUTO_FETLIFE_NEARBY_KEY as a, API_ENV_KEY as b, getApiBase as g, isTestMode as i };
//# sourceMappingURL=config-Dvlt12WH.js.map
